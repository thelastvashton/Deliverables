#!/bin/bash

awk '{print substr(FILENAME,1,4),$1,$2,$5,$6}' *Dealer_schedule | grep -i "$1"

