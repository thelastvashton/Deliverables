#!/bin/bash

awk '{print substr(FILENAME,1,4),$1,$2,"BLACKJACK:",$3,$4,"ROULETTE:",$5,$6,"TEXAS HOLD EM:",$7,$8}' *Dealer_schedule | grep -i "$1"

